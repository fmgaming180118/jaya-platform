
import os
import sys
from safeguard import Safeguard

if __name__ == "__main__":
    sg = Safeguard()
    # Find latest backup
    backups = sorted([f for f in os.listdir("backups") if f.endswith(".zip")])
    if backups:
        latest = os.path.join("backups", backups[-1])
        print(f"Restoring {latest}...")
        sg.restore_backup(latest)
    else:
        print("No backups found!")
