
import os
import yaml
from dotenv import load_dotenv
from openai import OpenAI

# Load environment variables from .env
load_dotenv()

class Teacher:
    def __init__(self, config_path="config.yaml"):
        self.config = self._load_config(config_path)
        self.api_key = os.getenv("NVIDIA_API_KEY")
        
        if not self.api_key:
            raise ValueError("NVIDIA_API_KEY not found in environment variables or .env file.")

        self.client = OpenAI(
            base_url=self.config["teacher"]["api_base"],
            api_key=self.api_key
        )
        self.model = self.config["teacher"]["model"]

    def _load_config(self, path):
        with open(path, "r") as f:
            return yaml.safe_load(f)

    def ask(self, prompt, system_instruction="You are a helpful AI assistant."):
        """
        Sends a prompt to the Teacher (NVIDIA NIM) and returns the response.
        """
        try:
            completion = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_instruction},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,
                top_p=0.7,
                max_tokens=1024,
            )
            return completion.choices[0].message.content
        except Exception as e:
            return f"Error communicating with Teacher: {e}"

if __name__ == "__main__":
    # Internal Test
    try:
        teacher = Teacher()
        print(f"[*] Connected to Teacher: {teacher.model}")
        print("[*] Sending test query...")
        response = teacher.ask("What is 2 + 2? Answer with just the number.")
        print(f"[*] Teacher Response: {response}")
    except Exception as e:
        print(f"[!] Setup Failed: {e}")
